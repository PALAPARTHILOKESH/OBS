import React from 'react'

const Footer = () => {
  return (
    <div style={{position:'fixed',bottom:0,backgroundColor:'#1565C0',color:'white',width:'100%',padding:'8px'}}>
    <center>@Copyright Reserved by LPS</center>
    </div>
  )
}

export default Footer