import React from 'react'
import Sidebar from './Sidebar'

const Messages = () => {
  return (
    <div><Sidebar/>Messages</div>
  )
}

export default Messages